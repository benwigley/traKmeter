
This directory contains simple "Hello World" type projects that you can copy and alter to
quickly create a JUCE application.

For a more complete example, see the Juce demo app.
